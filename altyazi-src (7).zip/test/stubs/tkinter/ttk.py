from . import _W
Frame=Label=Entry=Button=Combobox=_W
