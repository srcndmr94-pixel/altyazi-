package com.example.altyazi

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Oyun adını ve son replikleri bağlam olarak verip Anthropic API'sinden
 * daha doğru, karakter tutarlı bir Türkçe çeviri ister.
 */
class AiTranslate(private val prefs: Prefs) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .writeTimeout(5, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    /** Son çevrilen replikler; karakter ve konu tutarlılığı için gönderilir. */
    private val history = ArrayDeque<Pair<String, String>>()

    @Volatile
    var lastError: String? = null
        private set

    companion object Usage {
        const val FALLBACK_MODEL = "claude-3-5-haiku-latest"

        /** Bu oturumda harcanan jetonlar; ana ekranda gösterilir. */
        @Volatile var requests = 0
        @Volatile var inputTokens = 0
        @Volatile var outputTokens = 0
        @Volatile var cacheHits = 0

        /** Aynı repliği ikinci kez sunucuya göndermemek için. */
        private val cache = LinkedHashMap<String, String>()

        fun cached(text: String): String? = synchronized(cache) { cache[text] }

        fun remember(text: String, translation: String) = synchronized(cache) {
            if (cache.size > 400) cache.remove(cache.keys.first())
            cache[text] = translation
        }

        fun summary(): String =
            "Bu oturum: $requests istek · ${inputTokens} giriş · ${outputTokens} çıkış jetonu · " +
                "$cacheHits tekrar ücretsiz karşılandı"
    }

    fun remember(english: String, turkish: String) {
        history.addLast(english to turkish)
        while (history.size > 2) history.removeFirst()
    }

    fun clearHistory() = history.clear()

    suspend fun translate(text: String): String? = withContext(Dispatchers.IO) {
        val key = prefs.apiKey
        if (key.isBlank()) {
            lastError = "API anahtarı girilmemiş"
            return@withContext null
        }

        Usage.cached(text)?.let {
            Usage.cacheHits++
            lastError = null
            return@withContext it
        }

        val first = request(text, prefs.model, key)
        if (first != null) return@withContext first

        // Model adı kabul edilmediyse hesapta gerçekte hangi modeller varsa onu sor.
        val err = lastError ?: ""
        if (err.contains("404") || err.contains("not_found", ignoreCase = true)) {
            val auto = pickBest(fetchModels(key))
            if (auto != null && auto != prefs.model) {
                val second = request(text, auto, key)
                if (second != null) {
                    prefs.model = auto
                    return@withContext second
                }
            }
            if (lastError != null) {
                lastError = "Hesabınızda kullanılabilir model bulunamadı. " +
                    "Uygulamada MODELLERİ BUL tuşuna basın."
            }
        }
        null
    }

    /** Hesabın gerçekten erişebildiği model adlarını getirir. */
    fun fetchModels(key: String): List<String> {
        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/models?limit=100")
            .addHeader("x-api-key", key)
            .addHeader("anthropic-version", "2023-06-01")
            .get()
            .build()

        return try {
            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    lastError = shortError(resp.code, raw)
                    return emptyList()
                }
                val arr = JSONObject(raw).optJSONArray("data") ?: return emptyList()
                val out = ArrayList<String>()
                for (i in 0 until arr.length()) {
                    val id = arr.optJSONObject(i)?.optString("id").orEmpty()
                    if (id.isNotBlank()) out.add(id)
                }
                lastError = null
                out
            }
        } catch (e: Throwable) {
            lastError = e.message ?: "bağlantı hatası"
            emptyList()
        }
    }

    /** Altyazı için en uygunu: en hızlı olan. Yoksa eldeki ilk model. */
    fun pickBest(models: List<String>): String? {
        if (models.isEmpty()) return null
        return models.firstOrNull { it.contains("haiku", ignoreCase = true) }
            ?: models.firstOrNull { it.contains("sonnet", ignoreCase = true) }
            ?: models.first()
    }

    private fun request(text: String, model: String, key: String): String? {
        val game = prefs.gameName.ifBlank { "bilinmeyen bir video oyunu" }

        // Talimat her istekte tekrar gönderildiği için kısa tutuluyor; uzun
        // talimat, jetonun büyük kısmını çeviriye değil tarife harcar.
        val sb = StringBuilder()
        sb.append("Oyun altyazısı çevirmeni. Oyun: ").append(game).append(". ")
        sb.append("OCR ile okunmuş İngilizce repliği doğal Türkçeye çevir. ")
        sb.append("Özel isimleri çevirme. OCR hatalarını bağlamdan düzelt. Argoyu yumuşatma. ")
        if (prefs.showSpeaker) {
            sb.append("Replikte konuşan adı varsa 'İsim: çeviri' biçiminde koru. ")
        }
        sb.append("Sadece çeviriyi yaz, açıklama yazma, mutlaka bir çeviri ver.")

        val messages = JSONArray()
        for ((en, tr) in history) {
            messages.put(JSONObject().put("role", "user").put("content", en))
            messages.put(JSONObject().put("role", "assistant").put("content", tr))
        }
        messages.put(JSONObject().put("role", "user").put("content", text))

        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 400)
            .put("system", sb.toString())
            .put("messages", messages)
            .toString()
            .toRequestBody("application/json".toMediaType())

        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("x-api-key", key)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(body)
            .build()

        return try {
            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    lastError = shortError(resp.code, raw)
                    return null
                }
                val json = JSONObject(raw)
                json.optJSONObject("usage")?.let { u ->
                    Usage.requests++
                    Usage.inputTokens += u.optInt("input_tokens")
                    Usage.outputTokens += u.optInt("output_tokens")
                }
                val content = json.optJSONArray("content")
                val out = StringBuilder()
                val types = StringBuilder()
                if (content != null) {
                    for (i in 0 until content.length()) {
                        val part = content.optJSONObject(i) ?: continue
                        val type = part.optString("type")
                        if (types.isNotEmpty()) types.append(",")
                        types.append(type)
                        // Bazı modeller önce düşünme bloğu döndürür; metin bloklarını topluyoruz.
                        if (type == "text") out.append(part.optString("text"))
                    }
                }
                val result = out.toString().trim().trim('"')
                if (result.isBlank() || result == "-") {
                    // Boş dönüşün sebebini görebilmek için özetini saklıyoruz.
                    val stop = json.optString("stop_reason", "?")
                    lastError = "boş yanıt · model=$model · stop=$stop · blok=$types"
                    null
                } else {
                    lastError = null
                    Usage.remember(text, result)
                    result
                }
            }
        } catch (e: Throwable) {
            lastError = e.message ?: "bağlantı hatası"
            null
        }
    }

    private fun shortError(code: Int, raw: String): String {
        val msg = try {
            JSONObject(raw).optJSONObject("error")?.optString("message").orEmpty()
        } catch (_: Throwable) {
            ""
        }
        val shown = if (msg.isBlank()) raw.take(120) else msg.take(120)
        return "$code: $shown"
    }

}
