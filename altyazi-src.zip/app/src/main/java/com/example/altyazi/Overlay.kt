package com.example.altyazi

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

/**
 * Ekranın üstünde duran çeviri kutusu.
 * Üstte durmasının sebebi: altyazı bölgesini okurken kendi yazımızı okumamak.
 */
class Overlay(private val context: Context) {

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: FrameLayout? = null
    private var tv: TextView? = null

    fun show() {
        if (root != null) return

        val text = TextView(context).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            setShadowLayer(6f, 0f, 2f, Color.BLACK)
            val p = dp(12)
            setPadding(p, dp(8), p, dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Color.argb(190, 0, 0, 0))
            }
            visibility = View.GONE
        }

        val container = FrameLayout(context).apply {
            val p = dp(10)
            setPadding(p, dp(6), p, p)
            addView(
                text,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT
                ).apply { gravity = Gravity.CENTER_HORIZONTAL }
            )
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(28)
        }

        try {
            wm.addView(container, lp)
            root = container
            tv = text
        } catch (_: Throwable) {
        }
    }

    /** Boş metin verilirse kutu kaybolur. */
    fun setText(value: String?) {
        val t = tv ?: return
        t.post {
            if (value.isNullOrBlank()) {
                t.visibility = View.GONE
                t.text = ""
            } else {
                t.text = value
                t.visibility = View.VISIBLE
            }
        }
    }

    fun hide() {
        val r = root ?: return
        try {
            wm.removeView(r)
        } catch (_: Throwable) {
        }
        root = null
        tv = null
    }

    private fun dp(value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()
}
