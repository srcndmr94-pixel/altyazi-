package com.example.altyazi

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.EditText
import android.widget.SeekBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs

    private lateinit var etGame: EditText
    private lateinit var etKey: EditText
    private lateinit var etModel: EditText
    private lateinit var rgMode: RadioGroup
    private lateinit var cbSpeaker: CheckBox
    private lateinit var cbDiag: CheckBox
    private lateinit var sbTop: SeekBar
    private lateinit var sbBottom: SeekBar
    private lateinit var sbSpeed: SeekBar
    private lateinit var tvRegion: TextView
    private lateinit var tvSpeed: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvError: TextView

    private lateinit var projectionLauncher: ActivityResultLauncher<Intent>

    /** Arayüz kurulduysa true. Kurulamadıysa güvenli ekrandayız. */
    private var uiReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            buildUi()
            uiReady = true
        } catch (e: Throwable) {
            CrashLog.note(this, "acilis ekrani", e)
            showSafeScreen()
        }
    }

    /** Arayüz kurulamazsa uygulama kapanmasın; hatayı ekranda göster. */
    private fun showSafeScreen() {
        val info = TextView(this).apply {
            setPadding(40, 60, 40, 40)
            textSize = 13f
            text = "Uygulama açılırken bir sorun çıktı.\n\n" +
                (CrashLog.read(this@MainActivity) ?: "Ayrıntı kaydedilemedi.") +
                "\n\nBu yazıyı kopyalayıp sohbete yapıştırın."
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(this).apply { addView(info) }
        setContentView(scroll)
    }

    private fun buildUi() {
        setContentView(R.layout.activity_main)

        prefs = Prefs(this)

        etGame = findViewById(R.id.etGame)
        etKey = findViewById(R.id.etKey)
        etModel = findViewById(R.id.etModel)
        rgMode = findViewById(R.id.rgMode)
        cbSpeaker = findViewById(R.id.cbSpeaker)
        cbDiag = findViewById(R.id.cbDiag)
        sbTop = findViewById(R.id.sbTop)
        sbBottom = findViewById(R.id.sbBottom)
        sbSpeed = findViewById(R.id.sbSpeed)
        tvRegion = findViewById(R.id.tvRegion)
        tvSpeed = findViewById(R.id.tvSpeed)
        tvStatus = findViewById(R.id.tvStatus)

        etGame.setText(prefs.gameName)
        etKey.setText(prefs.apiKey)
        etModel.setText(prefs.model)
        findViewById<RadioButton>(
            when (prefs.mode) {
                Prefs.MODE_AI -> R.id.rbAi
                Prefs.MODE_HYBRID -> R.id.rbHybrid
                else -> R.id.rbInstant
            }
        ).isChecked = true
        cbSpeaker.isChecked = prefs.showSpeaker
        cbDiag.isChecked = prefs.diagnostics
        sbTop.progress = prefs.topPct
        sbBottom.progress = prefs.bottomPct
        sbSpeed.progress = (prefs.intervalMs - 100).coerceIn(0, 900)
        updateRegionLabel()
        updateSpeedLabel()

        val regionListener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) = updateRegionLabel()
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        }
        sbTop.setOnSeekBarChangeListener(regionListener)
        sbBottom.setOnSeekBarChangeListener(regionListener)

        sbSpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) = updateSpeedLabel()
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        projectionLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                val intent = Intent(this, CaptureService::class.java).apply {
                    action = CaptureService.ACTION_START
                    putExtra(CaptureService.EXTRA_CODE, result.resultCode)
                    putExtra(CaptureService.EXTRA_DATA, data)
                }
                ContextCompat.startForegroundService(this, intent)
                tvStatus.text = "Çalışıyor. Şimdi Chiaki'yi açıp oyuna girebilirsiniz."
                moveTaskToBack(true)
            } else {
                tvStatus.text = "Ekran yakalama izni verilmedi."
            }
        }

        tvError = findViewById(R.id.tvError)
        findViewById<Button>(R.id.btnCopyError).setOnClickListener { copyError() }

        findViewById<Button>(R.id.btnStart).setOnClickListener { save(); start() }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            val intent = Intent(this, CaptureService::class.java).apply {
                action = CaptureService.ACTION_STOP
            }
            startService(intent)
            tvStatus.text = "Durduruldu."
        }
    }

    override fun onResume() {
        super.onResume()
        if (!uiReady) return
        try {
            showError()
        } catch (_: Throwable) {
        }
    }

    override fun onPause() {
        super.onPause()
        if (!uiReady) return
        try {
            save()
        } catch (_: Throwable) {
        }
    }

    private fun showError() {
        val text = CrashLog.read(this)
        if (text.isNullOrBlank()) {
            tvError.text = "Kayıtlı hata yok."
        } else {
            tvError.text = text
        }
    }

    private fun copyError() {
        val text = CrashLog.read(this)
        if (text.isNullOrBlank()) {
            Toast.makeText(this, "Kayıtlı hata yok.", Toast.LENGTH_SHORT).show()
            return
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("Altyazı hata", text))
        Toast.makeText(this, "Hata kopyalandı, sohbete yapıştırabilirsiniz.", Toast.LENGTH_LONG).show()
    }

    private fun updateRegionLabel() {
        tvRegion.text = "Altyazının bulunduğu bölge: ekranın %${sbTop.progress} – %${sbBottom.progress} arası"
    }

    private fun updateSpeedLabel() {
        tvSpeed.text = "Her ${sbSpeed.progress + 100} ms'de bir tara (küçük = daha hızlı tepki, daha çok pil)"
    }

    private fun save() {
        prefs.gameName = etGame.text.toString()
        prefs.apiKey = etKey.text.toString()
        prefs.model = etModel.text.toString()
        prefs.mode = when (rgMode.checkedRadioButtonId) {
            R.id.rbAi -> Prefs.MODE_AI
            R.id.rbHybrid -> Prefs.MODE_HYBRID
            else -> Prefs.MODE_INSTANT
        }
        prefs.showSpeaker = cbSpeaker.isChecked
        prefs.diagnostics = cbDiag.isChecked
        prefs.intervalMs = sbSpeed.progress + 100

        var top = sbTop.progress
        var bottom = sbBottom.progress
        if (bottom <= top) {
            bottom = (top + 10).coerceAtMost(100)
            sbBottom.progress = bottom
        }
        if (top >= bottom) {
            top = (bottom - 10).coerceAtLeast(0)
            sbTop.progress = top
        }
        prefs.topPct = top
        prefs.bottomPct = bottom
    }

    private fun start() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
            tvStatus.text = "Bildirim iznini verin, sonra tekrar BAŞLAT deyin."
            return
        }

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Önce 'diğer uygulamaların üzerinde göster' iznini verin.", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            tvStatus.text = "İzni verdikten sonra geri gelip tekrar BAŞLAT deyin."
            return
        }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
}
