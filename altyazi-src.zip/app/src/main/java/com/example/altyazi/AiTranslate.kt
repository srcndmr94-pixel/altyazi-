package com.example.altyazi

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Oyun adını ve son replikleri bağlam olarak verip Anthropic API'sinden
 * daha doğru, karakter tutarlı bir Türkçe çeviri ister.
 */
class AiTranslate(private val prefs: Prefs) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .writeTimeout(5, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    /** Son çevrilen replikler; karakter ve konu tutarlılığı için gönderilir. */
    private val history = ArrayDeque<Pair<String, String>>()

    @Volatile
    var lastError: String? = null
        private set

    fun remember(english: String, turkish: String) {
        history.addLast(english to turkish)
        while (history.size > 4) history.removeFirst()
    }

    fun clearHistory() = history.clear()

    suspend fun translate(text: String): String? = withContext(Dispatchers.IO) {
        val key = prefs.apiKey
        if (key.isBlank()) {
            lastError = "API anahtarı girilmemiş"
            return@withContext null
        }

        val first = request(text, prefs.model, key)
        if (first != null) return@withContext first

        // Model adı kabul edilmediyse bir kez de eski isimle dene.
        val err = lastError ?: ""
        if (err.contains("model", ignoreCase = true) || err.contains("404")) {
            val second = request(text, FALLBACK_MODEL, key)
            if (second != null) {
                prefs.model = FALLBACK_MODEL
                return@withContext second
            }
        }
        null
    }

    private fun request(text: String, model: String, key: String): String? {
        val game = prefs.gameName.ifBlank { "bilinmeyen bir video oyunu" }

        val sb = StringBuilder()
        sb.append("Sen bir video oyunu altyazı çevirmenisin. Oyun: ").append(game).append(". ")
        sb.append("Sana ekrandan OCR ile okunmuş İngilizce bir replik veriyorum. ")
        sb.append("Onu doğal, akıcı Türkçeye çevir. Kurallar: ")
        sb.append("Karakter, yer ve eşya isimlerini çevirme, olduğu gibi bırak. ")
        sb.append("OCR hatalarını bağlama göre kendin düzelt. ")
        sb.append("Küfür ve argoyu yumuşatmadan çevir. ")
        if (prefs.showSpeaker) {
            sb.append("Konuşanın kim olduğundan eminsen çevirinin başına [İsim] ekle, emin değilsen ekleme. ")
        }
        sb.append("SADECE Türkçe çeviriyi yaz. Açıklama, tırnak, ek cümle yazma. ")
        sb.append("Çeviri kısa ve tek seferde okunabilir olsun; oyuncu bunu ekranda anlık okuyor. ")
        sb.append("Metin anlamsızsa veya altyazı değilse sadece tek bir tire (-) yaz.")

        val messages = JSONArray()
        for ((en, tr) in history) {
            messages.put(JSONObject().put("role", "user").put("content", en))
            messages.put(JSONObject().put("role", "assistant").put("content", tr))
        }
        messages.put(JSONObject().put("role", "user").put("content", text))

        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 150)
            .put("temperature", 0.2)
            .put("system", sb.toString())
            .put("messages", messages)
            .toString()
            .toRequestBody("application/json".toMediaType())

        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("x-api-key", key)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(body)
            .build()

        return try {
            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    lastError = shortError(resp.code, raw)
                    return null
                }
                val content = JSONObject(raw).optJSONArray("content")
                val out = StringBuilder()
                if (content != null) {
                    for (i in 0 until content.length()) {
                        val part = content.optJSONObject(i) ?: continue
                        if (part.optString("type") == "text") out.append(part.optString("text"))
                    }
                }
                val result = out.toString().trim().trim('"')
                if (result.isBlank() || result == "-") {
                    lastError = null
                    null
                } else {
                    lastError = null
                    result
                }
            }
        } catch (e: Throwable) {
            lastError = e.message ?: "bağlantı hatası"
            null
        }
    }

    private fun shortError(code: Int, raw: String): String {
        val msg = try {
            JSONObject(raw).optJSONObject("error")?.optString("message").orEmpty()
        } catch (_: Throwable) {
            ""
        }
        val shown = if (msg.isBlank()) raw.take(120) else msg.take(120)
        return "$code: $shown"
    }

    companion object {
        const val FALLBACK_MODEL = "claude-3-5-haiku-latest"
    }
}
