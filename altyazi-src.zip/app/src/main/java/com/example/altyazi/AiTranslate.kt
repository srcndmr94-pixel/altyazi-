package com.example.altyazi

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Oyun adını ve son replikleri bağlam olarak verip Anthropic API'sinden
 * daha doğru, karakter tutarlı bir Türkçe çeviri ister.
 */
class AiTranslate(private val prefs: Prefs) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .writeTimeout(5, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    /** Son çevrilen replikler; karakter ve konu tutarlılığı için gönderilir. */
    private val history = ArrayDeque<Pair<String, String>>()

    @Volatile
    var lastError: String? = null
        private set

    fun remember(english: String, turkish: String) {
        history.addLast(english to turkish)
        while (history.size > 4) history.removeFirst()
    }

    fun clearHistory() = history.clear()

    suspend fun translate(text: String): String? = withContext(Dispatchers.IO) {
        val key = prefs.apiKey
        if (key.isBlank()) {
            lastError = "API anahtarı girilmemiş"
            return@withContext null
        }

        val first = request(text, prefs.model, key)
        if (first != null) return@withContext first

        // Model adı kabul edilmediyse hesapta gerçekte hangi modeller varsa onu sor.
        val err = lastError ?: ""
        if (err.contains("model", ignoreCase = true) || err.contains("404")) {
            val auto = pickBest(fetchModels(key))
            if (auto != null && auto != prefs.model) {
                val second = request(text, auto, key)
                if (second != null) {
                    prefs.model = auto
                    return@withContext second
                }
            }
            if (lastError != null) {
                lastError = "Hesabınızda kullanılabilir model bulunamadı. " +
                    "Uygulamada MODELLERİ BUL tuşuna basın."
            }
        }
        null
    }

    /** Hesabın gerçekten erişebildiği model adlarını getirir. */
    fun fetchModels(key: String): List<String> {
        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/models?limit=100")
            .addHeader("x-api-key", key)
            .addHeader("anthropic-version", "2023-06-01")
            .get()
            .build()

        return try {
            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    lastError = shortError(resp.code, raw)
                    return emptyList()
                }
                val arr = JSONObject(raw).optJSONArray("data") ?: return emptyList()
                val out = ArrayList<String>()
                for (i in 0 until arr.length()) {
                    val id = arr.optJSONObject(i)?.optString("id").orEmpty()
                    if (id.isNotBlank()) out.add(id)
                }
                lastError = null
                out
            }
        } catch (e: Throwable) {
            lastError = e.message ?: "bağlantı hatası"
            emptyList()
        }
    }

    /** Altyazı için en uygunu: en hızlı olan. Yoksa eldeki ilk model. */
    fun pickBest(models: List<String>): String? {
        if (models.isEmpty()) return null
        return models.firstOrNull { it.contains("haiku", ignoreCase = true) }
            ?: models.firstOrNull { it.contains("sonnet", ignoreCase = true) }
            ?: models.first()
    }

    private fun request(text: String, model: String, key: String): String? {
        val game = prefs.gameName.ifBlank { "bilinmeyen bir video oyunu" }

        val sb = StringBuilder()
        sb.append("Sen bir video oyunu altyazı çevirmenisin. Oyun: ").append(game).append(". ")
        sb.append("Sana ekrandan OCR ile okunmuş İngilizce bir replik veriyorum. ")
        sb.append("Onu doğal, akıcı Türkçeye çevir. Kurallar: ")
        sb.append("ÖZEL İSİMLERİ ASLA ÇEVİRME. Karakter, yer, gemi ve eşya adları İngilizce kalsın. ")
        sb.append("Hope, Faith, Rose, Grace, Hunter gibi Türkçe karşılığı varmış gibi duran isimler de ")
        sb.append("isim olarak kalır, kelime anlamına çevrilmez. ")
        sb.append("OCR hatalarını bağlama göre kendin düzelt. ")
        sb.append("Küfür ve argoyu yumuşatmadan çevir. ")
        if (prefs.showSpeaker) {
            sb.append("Replik 'JAMES: ...' gibi konuşanın adıyla geliyorsa adı aynen koru ve ")
            sb.append("çeviriyi 'James: çeviri' biçiminde yaz. Ad yoksa ve konuşanın kim olduğundan ")
            sb.append("eminsen 'İsim: çeviri' biçimini yine kullan; emin değilsen hiç isim yazma. ")
            sb.append("İsmi asla çevirinin içine karıştırma, her zaman iki nokta üst üsteden önce dursun. ")
        }
        sb.append("SADECE Türkçe çeviriyi yaz. Açıklama, tırnak, ek cümle yazma. ")
        sb.append("Çeviri kısa ve tek seferde okunabilir olsun; oyuncu bunu ekranda anlık okuyor. ")
        sb.append("Metin OCR yüzünden eksik veya bozuk harfler içerebilir; cümleyi bağlama göre ")
        sb.append("mantıklı biçimde tamamla ve mutlaka bir çeviri ver. Çeviremiyorum deme, tire koyma. ")
        sb.append("İçinde oyun arayüzünden karışmış kelimeler varsa (tuş adı, görev yazısı) onları at, ")
        sb.append("sadece konuşma cümlesini çevir.")

        val messages = JSONArray()
        for ((en, tr) in history) {
            messages.put(JSONObject().put("role", "user").put("content", en))
            messages.put(JSONObject().put("role", "assistant").put("content", tr))
        }
        messages.put(JSONObject().put("role", "user").put("content", text))

        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 150)
            .put("temperature", 0.2)
            .put("system", sb.toString())
            .put("messages", messages)
            .toString()
            .toRequestBody("application/json".toMediaType())

        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("x-api-key", key)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(body)
            .build()

        return try {
            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    lastError = shortError(resp.code, raw)
                    return null
                }
                val content = JSONObject(raw).optJSONArray("content")
                val out = StringBuilder()
                if (content != null) {
                    for (i in 0 until content.length()) {
                        val part = content.optJSONObject(i) ?: continue
                        if (part.optString("type") == "text") out.append(part.optString("text"))
                    }
                }
                val result = out.toString().trim().trim('"')
                if (result.isBlank() || result == "-") {
                    lastError = null
                    null
                } else {
                    lastError = null
                    result
                }
            }
        } catch (e: Throwable) {
            lastError = e.message ?: "bağlantı hatası"
            null
        }
    }

    private fun shortError(code: Int, raw: String): String {
        val msg = try {
            JSONObject(raw).optJSONObject("error")?.optString("message").orEmpty()
        } catch (_: Throwable) {
            ""
        }
        val shown = if (msg.isBlank()) raw.take(120) else msg.take(120)
        return "$code: $shown"
    }

    companion object {
        const val FALLBACK_MODEL = "claude-3-5-haiku-latest"
    }
}
