package com.example.altyazi

import android.content.Context

/** Tüm ayarlar burada saklanır. Servis ve ekran aynı yerden okur. */
class Prefs(context: Context) {

    private val sp = context.applicationContext
        .getSharedPreferences("altyazi", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("apiKey", "") ?: ""
        set(v) = sp.edit().putString("apiKey", v.trim()).apply()

    /** Oyun, Dizi, Film gibi içerik türü. Çeviri talimatına girer. */
    var contentType: String
        get() = (sp.getString("contentType", "") ?: "").ifBlank { "Oyun" }
        set(v) = sp.edit().putString("contentType", v.trim()).apply()

    var gameName: String
        get() = sp.getString("gameName", "") ?: ""
        set(v) = sp.edit().putString("gameName", v.trim()).apply()

    /** 0 = Anthropic (ücretli), 1 = Google Gemini (ücretsiz katman). */
    var provider: Int
        get() = sp.getInt("provider", PROVIDER_GEMINI)
        set(v) = sp.edit().putInt("provider", v).apply()

    /** Google AI Studio anahtarı. */
    var geminiKey: String
        get() = (sp.getString("geminiKey", "") ?: "").ifBlank { GOMULU_ANAHTAR }
        set(v) = sp.edit().putString("geminiKey", v.trim()).apply()

    var geminiModel: String
        get() = (sp.getString("geminiModel", "") ?: "").ifBlank { DEFAULT_GEMINI_MODEL }
        set(v) = sp.edit().putString("geminiModel", v.trim()).apply()

    /** Seçili sağlayıcının anahtarı. */
    val activeKey: String
        get() = if (provider == PROVIDER_GEMINI) geminiKey else apiKey

    var model: String
        get() = (sp.getString("model", "") ?: "").ifBlank { DEFAULT_MODEL }
        set(v) = sp.edit().putString("model", v.trim()).apply()

    /**
     * 0 = Anında: sadece telefonun içindeki çeviri, ~0,3 sn, hiç değişmez.
     * 1 = Yapay zekâ: ~1 sn gecikir, hiç değişmez, en doğru çeviri.
     * 2 = Karma: önce anında çıkar, yapay zekâ gelince bir kez düzelir.
     */
    var mode: Int
        get() = sp.getInt("mode", MODE_AI)
        set(v) = sp.edit().putInt("mode", v).apply()

    val useAi: Boolean
        get() = mode != MODE_INSTANT

    var showSpeaker: Boolean
        get() = sp.getBoolean("showSpeaker", true)
        set(v) = sp.edit().putBoolean("showSpeaker", v).apply()

    /** Menü, görev ve tuş yazılarını da kendi yerlerinde anında çevirsin mi? */
    var menuTranslate: Boolean
        get() = sp.getBoolean("menuTranslate", false)
        set(v) = sp.edit().putBoolean("menuTranslate", v).apply()

    /** Açıkken, çeviri çıkmadığında ekranda sebebini ve okunan metni gösterir. */
    var diagnostics: Boolean
        get() = sp.getBoolean("diagnostics", false)
        set(v) = sp.edit().putBoolean("diagnostics", v).apply()

    init {
        // Yeni sürümde altyazı bölgesi daha dar; eski kayıt varsa bir kez güncellenir.
        if (sp.getInt("defaultsVersion", 0) < 9) {
            sp.edit()
                .putInt("topPct", 74)
                .putInt("bottomPct", 99)
                .putBoolean("menuTranslate", false)
                .putInt("mode", MODE_AI)
                .putInt("intervalMs", 150)
                .putBoolean("diagnostics", false)
                .putString("geminiModel", "")
                .putInt("defaultsVersion", 9)
                .apply()
        }
    }

    /** Altyazı bölgesinin ekran yüksekliğine göre üst sınırı, yüzde. */
    var topPct: Int
        get() = sp.getInt("topPct", 74)
        set(v) = sp.edit().putInt("topPct", v).apply()

    /** Altyazı bölgesinin alt sınırı, yüzde. */
    var bottomPct: Int
        get() = sp.getInt("bottomPct", 99)
        set(v) = sp.edit().putInt("bottomPct", v).apply()

    /** İki tarama arasındaki bekleme, milisaniye. Küçük = hızlı ama daha çok pil. */
    var intervalMs: Int
        get() = sp.getInt("intervalMs", 150)
        set(v) = sp.edit().putInt("intervalMs", v).apply()

    companion object {
        /** Gömülü Google anahtarı; ayarlardan değiştirilebilir. */
        const val GOMULU_ANAHTAR = "AQ.Ab8RN6J9G3HMBqJ42-0YN9Ilzh2aOOEDnpy0dEP7CK5eD8gXHA"

        const val DEFAULT_MODEL = "claude-haiku-5-5"
        const val DEFAULT_GEMINI_MODEL = "gemini-3.8"
        const val PROVIDER_ANTHROPIC = 0
        const val PROVIDER_GEMINI = 1
        const val MODE_INSTANT = 0
        const val MODE_AI = 1
        const val MODE_HYBRID = 2
    }
}
