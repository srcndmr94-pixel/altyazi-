package com.example.altyazi

import android.content.Context

/** Tüm ayarlar burada saklanır. Servis ve ekran aynı yerden okur. */
class Prefs(context: Context) {

    private val sp = context.applicationContext
        .getSharedPreferences("altyazi", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("apiKey", "") ?: ""
        set(v) = sp.edit().putString("apiKey", v.trim()).apply()

    var gameName: String
        get() = sp.getString("gameName", "") ?: ""
        set(v) = sp.edit().putString("gameName", v.trim()).apply()

    var model: String
        get() = (sp.getString("model", "") ?: "").ifBlank { DEFAULT_MODEL }
        set(v) = sp.edit().putString("model", v.trim()).apply()

    var useAi: Boolean
        get() = sp.getBoolean("useAi", true)
        set(v) = sp.edit().putBoolean("useAi", v).apply()

    var showSpeaker: Boolean
        get() = sp.getBoolean("showSpeaker", true)
        set(v) = sp.edit().putBoolean("showSpeaker", v).apply()

    /** Altyazı bölgesinin ekran yüksekliğine göre üst sınırı, yüzde. */
    var topPct: Int
        get() = sp.getInt("topPct", 68)
        set(v) = sp.edit().putInt("topPct", v).apply()

    /** Altyazı bölgesinin alt sınırı, yüzde. */
    var bottomPct: Int
        get() = sp.getInt("bottomPct", 97)
        set(v) = sp.edit().putInt("bottomPct", v).apply()

    /** İki tarama arasındaki bekleme, milisaniye. Küçük = hızlı ama daha çok pil. */
    var intervalMs: Int
        get() = sp.getInt("intervalMs", 150)
        set(v) = sp.edit().putInt("intervalMs", v).apply()

    companion object {
        const val DEFAULT_MODEL = "claude-haiku-5-5"
    }
}
