package com.example.altyazi

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Telefonun içindeki, internetsiz çalışan hızlı çeviri.
 * Yapay zekâ cevabı gelene kadar ekranda bu durur.
 */
class FastTranslate {

    private val translator: Translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.TURKISH)
            .build()
    )

    @Volatile
    var ready: Boolean = false
        private set

    /** Model yoksa bir kereye mahsus indirir. Sonrası internetsiz çalışır. */
    suspend fun prepare(): Boolean = suspendCancellableCoroutine { cont ->
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                ready = true
                if (cont.isActive) cont.resume(true)
            }
            .addOnFailureListener {
                ready = false
                if (cont.isActive) cont.resume(false)
            }
    }

    suspend fun translate(text: String): String? {
        if (!ready) return null
        return suspendCancellableCoroutine { cont ->
            translator.translate(text)
                .addOnSuccessListener { if (cont.isActive) cont.resume(it) }
                .addOnFailureListener { if (cont.isActive) cont.resume(null) }
        }
    }

    fun close() {
        try {
            translator.close()
        } catch (_: Throwable) {
        }
    }
}
