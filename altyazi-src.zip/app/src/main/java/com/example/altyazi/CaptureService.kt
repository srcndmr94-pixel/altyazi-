package com.example.altyazi

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.min

class CaptureService : Service() {

    companion object {
        const val ACTION_START = "com.example.altyazi.START"
        const val ACTION_STOP = "com.example.altyazi.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"

        private const val CHANNEL_ID = "altyazi"
        private const val NOTIF_ID = 1001

        /** OCR için ekranı bu genişliğe küçültüyoruz. Daha küçük = daha hızlı. */
        private const val TARGET_WIDTH = 900
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var readerThread: HandlerThread? = null
    private var readerHandler: Handler? = null

    private lateinit var prefs: Prefs
    private lateinit var overlay: Overlay
    private var fast: FastTranslate? = null
    private var ai: AiTranslate? = null

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private var captureWidth = 0
    private var captureHeight = 0

    /** Sanal ekran bir kez kuruldu mu? Android ikinci kurulumu yasaklıyor. */
    private var displayCreated = false

    /** Ekranda şu an gösterilen çevirinin İngilizce kaynağı. */
    private var shownSource: String = ""

    /** Yeni okunan replik; çevirmeden önce üst üste aynı okunduğu doğrulanır. */
    private var candidate: String = ""
    private var candidateSeen: Int = 0

    /** Şu an çevirisi beklenen replik. Aynısı ikinci kez gönderilmez. */
    private var translatingFor: String = ""
    private var translateJob: Job? = null

    private var emptyFrames = 0
    private var noTextWarned = false
    private var everShown = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        overlay = Overlay(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopEverything()
                return START_NOT_STICKY
            }

            ACTION_START -> {
                startForegroundSafely()

                val code = intent.getIntExtra(EXTRA_CODE, 0)
                @Suppress("DEPRECATION")
                val data: Intent? = intent.getParcelableExtra(EXTRA_DATA)
                if (data == null) {
                    stopEverything()
                    return START_NOT_STICKY
                }

                if (projection == null) {
                    val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    val mp = try {
                        mpm.getMediaProjection(code, data)
                    } catch (_: Throwable) {
                        null
                    }
                    if (mp == null) {
                        stopEverything()
                        return START_NOT_STICKY
                    }
                    // Android 14+ sanal ekran açılmadan önce geri çağrı ister.
                    mp.registerCallback(object : MediaProjection.Callback() {
                        override fun onStop() {
                            stopEverything()
                        }
                    }, Handler(mainLooper))
                    projection = mp

                    overlay.show()
                    startPipeline()
                }
            }
        }
        return START_STICKY
    }

    // ---------------------------------------------------------------- kurulum

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(
                        CHANNEL_ID,
                        "Altyazı Çevir",
                        NotificationManager.IMPORTANCE_LOW
                    )
                )
            }
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID)
        else
            @Suppress("DEPRECATION") Notification.Builder(this)

        return builder
            .setContentTitle("Altyazı Çevir çalışıyor")
            .setContentText("Ekrandaki altyazı Türkçeye çevriliyor")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(openIntent)
            .addAction(
                Notification.Action.Builder(
                    null as android.graphics.drawable.Icon?,
                    "Durdur",
                    stopIntent
                ).build()
            )
            .setOngoing(true)
            .build()
    }

    private fun startForegroundSafely() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            @Suppress("DEPRECATION")
            val d = wm.defaultDisplay
            @Suppress("DEPRECATION")
            val p = android.graphics.Point().also { d.getRealSize(it) }
            p.x to p.y
        }
    }

    /**
     * Android, bir ekran yakalama izni için sanal ekranı YALNIZCA BİR KEZ
     * kurmaya izin veriyor; ikinci kez kurmaya kalkışmak uygulamayı kapattırıyor.
     * Bu yüzden telefon döndüğünde ekranı yeniden kurmuyoruz, var olanı
     * yeni ölçülere göre yeniden boyutlandırıyoruz.
     */
    private fun configureDisplay(): Boolean {
        val (sw, sh) = screenSize()
        if (sw <= 0 || sh <= 0) return false

        val scale = min(1f, TARGET_WIDTH.toFloat() / max(sw, 1))
        val w = max(2, (sw * scale).toInt() / 2 * 2)
        val h = max(2, (sh * scale).toInt() / 2 * 2)

        if (displayCreated && w == captureWidth && h == captureHeight) return true

        if (readerThread == null) {
            val thread = HandlerThread("altyazi-reader").also { it.start() }
            readerThread = thread
            readerHandler = Handler(thread.looper)
        }

        val reader = try {
            ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        } catch (e: Throwable) {
            CrashLog.note(this, "goruntu okuyucu", e)
            return false
        }

        return try {
            if (!displayCreated) {
                val vd = projection?.createVirtualDisplay(
                    "altyazi",
                    w, h,
                    resources.displayMetrics.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.surface,
                    null,
                    readerHandler
                )
                if (vd == null) {
                    reader.close()
                    return false
                }
                virtualDisplay = vd
                displayCreated = true
            } else {
                val vd = virtualDisplay
                if (vd == null) {
                    reader.close()
                    return false
                }
                vd.resize(w, h, resources.displayMetrics.densityDpi)
                vd.setSurface(reader.surface)
            }

            val old = imageReader
            imageReader = reader
            try {
                old?.close()
            } catch (_: Throwable) {
            }

            captureWidth = w
            captureHeight = h
            true
        } catch (e: Throwable) {
            CrashLog.note(this, "ekran kurulumu", e)
            try {
                reader.close()
            } catch (_: Throwable) {
            }
            false
        }
    }

    private fun releaseDisplay() {
        try {
            virtualDisplay?.release()
        } catch (_: Throwable) {
        }
        virtualDisplay = null
        try {
            imageReader?.close()
        } catch (_: Throwable) {
        }
        imageReader = null
        try {
            readerThread?.quitSafely()
        } catch (_: Throwable) {
        }
        readerThread = null
        readerHandler = null
        displayCreated = false
        captureWidth = 0
        captureHeight = 0
    }

    // ----------------------------------------------------------------- akış

    private fun startPipeline() {
        val f = FastTranslate()
        fast = f
        ai = AiTranslate(prefs)

        scope.launch {
            try {
                f.prepare()
            } catch (e: Throwable) {
                CrashLog.note(this@CaptureService, "ceviri modeli", e)
            }
        }

        scope.launch {
            if (!configureDisplay()) {
                stopEverything()
                return@launch
            }

            // Kutunun çalıştığı görünsün diye kısa bir karşılama yazısı.
            overlay.setText("Altyazı Çevir çalışıyor…")
            delay(2500)
            if (shownSource.isEmpty()) overlay.setText(null)

            var lastScreen = screenSize()

            while (isActive) {
                val interval = prefs.intervalMs.toLong().coerceIn(80L, 1000L)
                delay(interval)

                // Tek bir karedeki hata uygulamayı çökertmesin, döngü devam etsin.
                try {
                    // Telefon döndüyse sanal ekranı yeniden kur.
                    val now = screenSize()
                    if (now != lastScreen) {
                        lastScreen = now
                        configureDisplay()
                        delay(250)
                        continue
                    }

                    val bitmap = grabRegion() ?: continue
                    val text = runOcr(bitmap)
                    bitmap.recycle()
                    handleText(text)
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    CrashLog.note(this@CaptureService, "tarama dongusu", e)
                    delay(400)
                }
            }
        }
    }

    /** Ekrandan son kareyi alıp sadece altyazı bölgesini keser. */
    private fun grabRegion(): Bitmap? {
        val reader = imageReader ?: return null
        val image = try {
            reader.acquireLatestImage()
        } catch (_: Throwable) {
            null
        } ?: return null

        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width

            val full = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )
            full.copyPixelsFromBuffer(buffer)

            val topPct = prefs.topPct.coerceIn(0, 99)
            val bottomPct = prefs.bottomPct.coerceIn(topPct + 1, 100)

            val top = (image.height * topPct / 100).coerceIn(0, image.height - 2)
            val bottom = (image.height * bottomPct / 100).coerceIn(top + 2, image.height)

            val cropped = Bitmap.createBitmap(full, 0, top, image.width, bottom - top)
            if (cropped != full) full.recycle()
            cropped
        } catch (_: Throwable) {
            null
        } finally {
            try {
                image.close()
            } catch (_: Throwable) {
            }
        }
    }

    private suspend fun runOcr(bitmap: Bitmap): String =
        suspendCancellableCoroutine { cont ->
            try {
                recognizer.process(InputImage.fromBitmap(bitmap, 0))
                    .addOnSuccessListener { result ->
                        val lines = ArrayList<String>()
                        for (block in result.textBlocks) {
                            for (line in block.lines) {
                                val t = line.text.trim()
                                if (t.isNotEmpty()) lines.add(t)
                            }
                        }
                        if (cont.isActive) cont.resume(lines.joinToString(" "))
                    }
                    .addOnFailureListener {
                        if (cont.isActive) cont.resume("")
                    }
            } catch (_: Throwable) {
                if (cont.isActive) cont.resume("")
            }
        }

    /**
     * Tek kural: ekrandaki yazı bir replik için BİR KEZ yazılır ve o replik
     * değişene kadar hiç değiştirilmez. Yeni çeviri hazır olana kadar eski
     * yazı ekranda kalır, araya boşluk veya yarım çeviri girmez.
     */
    private fun handleText(raw: String) {
        val text = clean(raw)

        if (text.isEmpty()) {
            emptyFrames++
            // Uzun süre hiç yazı okunamıyorsa sebebi görünsün.
            if (prefs.diagnostics && !noTextWarned && !everShown && emptyFrames >= 60) {
                noTextWarned = true
                overlay.setText("⚠ Ekranda yazı okunamıyor. Altyazı bölgesi ayarını veya ekran yakalama iznini kontrol edin.")
                return
            }
            // Tek kare kaçırmak yazıyı söndürmesin; gerçekten gittiyse kaldır.
            if (emptyFrames >= 5 && shownSource.isNotEmpty()) {
                shownSource = ""
                candidate = ""
                candidateSeen = 0
                translatingFor = ""
                translateJob?.cancel()
                overlay.setText(null)
            }
            return
        }
        emptyFrames = 0

        // Ekrandaki replik hâlâ duruyor: hiçbir şey yapma, yazıya dokunma.
        if (similar(text, shownSource)) {
            candidate = ""
            candidateSeen = 0
            return
        }

        // Yeni replik, ama OCR yarım okumuş olabilir: aynısını iki kez görmeden çevirme.
        if (similar(text, candidate)) {
            candidateSeen++
        } else {
            candidate = text
            candidateSeen = 1
        }
        if (candidateSeen < 2) return

        // Bu replik için zaten çeviri bekleniyorsa tekrar gönderme.
        if (similar(text, translatingFor)) return

        val source = text
        translatingFor = source
        translateJob?.cancel()
        translateJob = scope.launch { runTranslation(source) }
    }

    /** Ekrana yaz, ama bu arada altyazı değiştiyse yazma. */
    private fun publish(source: String, value: String?) {
        if (translatingFor != source) return
        if (value.isNullOrBlank()) return
        shownSource = source
        everShown = true
        overlay.setText(value)
    }

    /** Seçilen hız moduna göre repliği çevirir. */
    private suspend fun runTranslation(source: String) {
        val mode = prefs.mode
        val engine = ai

        // Anında mod: sadece telefonun çevirisi, tek yazı, hiç değişmez.
        if (mode == Prefs.MODE_INSTANT) {
            val quick = fast?.translate(source)
            if (!quick.isNullOrBlank()) {
                publish(source, quick)
                return
            }
            if (fast?.ready == false) {
                publish(source, "⚠ Çeviri modeli inmedi. İnternete bağlanıp DURDUR–BAŞLAT yapın.")
                return
            }
            if (prefs.diagnostics) publish(source, "OKUNDU: $source")
            return
        }

        // Karma mod: önce anında yaz, yapay zekâ gelince bir kez düzelt.
        if (mode == Prefs.MODE_HYBRID) {
            val quick = fast?.translate(source)
            if (!quick.isNullOrBlank()) publish(source, quick)
        }

        if (prefs.apiKey.isBlank() || engine == null) {
            publish(source, "⚠ API anahtarı girilmemiş")
            return
        }

        val better = engine.translate(source)
        if (!better.isNullOrBlank()) {
            engine.remember(source, better)
            publish(source, better)
            return
        }

        // Yapay zekâ olmadı: yedek olarak telefonun çevirisi.
        val err = engine.lastError
        if (mode != Prefs.MODE_HYBRID) {
            val quick = fast?.translate(source)
            if (!quick.isNullOrBlank()) {
                publish(source, quick)
                return
            }
        }
        if (err != null) publish(source, "⚠ $err")
        else if (prefs.diagnostics) publish(source, "OKUNDU: $source")
    }

    // ------------------------------------------------------------- yardımcı

    /** OCR çöpünü ayıklar: tek harfler, sadece sayı/simge olan satırlar. */
    private fun clean(raw: String): String {
        val collapsed = raw.replace(Regex("\\s+"), " ").trim()
        if (collapsed.length < 3) return ""
        val letters = collapsed.count { it.isLetter() }
        if (letters < 3) return ""
        if (letters.toFloat() / collapsed.length < 0.45f) return ""
        return collapsed
    }

    private fun normalize(s: String): String =
        s.lowercase().filter { it.isLetterOrDigit() }

    private fun similar(a: String, b: String): Boolean {
        if (a.isEmpty() || b.isEmpty()) return a == b
        val na = normalize(a)
        val nb = normalize(b)
        if (na == nb) return true
        if (na.isEmpty() || nb.isEmpty()) return false
        val longer = if (na.length >= nb.length) na else nb
        val shorter = if (na.length >= nb.length) nb else na
        if (shorter.length.toFloat() / longer.length < 0.8f) return false
        val distance = levenshtein(shorter, longer)
        return distance.toFloat() / longer.length <= 0.12f
    }

    private fun levenshtein(a: String, b: String): Int {
        val prev = IntArray(b.length + 1) { it }
        val cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            System.arraycopy(cur, 0, prev, 0, cur.size)
        }
        return prev[b.length]
    }

    // --------------------------------------------------------------- kapanış

    private fun stopEverything() {
        try {
            scope.cancel()
        } catch (_: Throwable) {
        }
        releaseDisplay()
        try {
            projection?.stop()
        } catch (_: Throwable) {
        }
        projection = null
        fast?.close()
        fast = null
        ai = null
        overlay.setText(null)
        overlay.hide()
        try {
            recognizer.close()
        } catch (_: Throwable) {
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        releaseDisplay()
        try {
            projection?.stop()
        } catch (_: Throwable) {
        }
        overlay.hide()
        super.onDestroy()
    }
}
