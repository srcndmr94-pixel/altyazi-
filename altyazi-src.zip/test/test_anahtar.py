"""Gömülü anahtar gerçekten geliyor mu?"""
import importlib.util, os, sys, json, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "stubs"))
spec = importlib.util.spec_from_file_location("lingoplay", "/home/claude/project/pc/lingoplay_pc.py")
lp = importlib.util.module_from_spec(spec); spec.loader.exec_module(lp)

hata = []
def kontrol(ad, kosul, ek=""):
    print(("  ✓ " if kosul else "  ✗ ") + ad + ("" if kosul else f"  {ek}"))
    if not kosul: hata.append(ad)

kontrol("sürüm 4.1", lp.SURUM == "4.1", lp.SURUM)
kontrol("varsayılanda anahtar dolu", lp.VARSAYILAN["api_key"].startswith("AQ."), lp.VARSAYILAN["api_key"][:6])

# ayar dosyası yokmuş gibi
lp.CONFIG_PATH = os.path.join(tempfile.mkdtemp(), "yok.json")
a = lp.ayarlari_yukle()
kontrol("ayar dosyası yokken anahtar geliyor", a["api_key"] == lp.GOMULU_ANAHTAR)

# ayar dosyası var ama anahtar boş
yol = os.path.join(tempfile.mkdtemp(), "ayar.json")
json.dump({"api_key": "", "oyun": "X"}, open(yol, "w"))
lp.CONFIG_PATH = yol
a2 = lp.ayarlari_yukle()
kontrol("boş kayıtta gömülü anahtara düşüyor", a2["api_key"] == lp.GOMULU_ANAHTAR, a2["api_key"])
kontrol("diğer ayarlar korunuyor", a2["oyun"] == "X")

# kullanıcı kendi anahtarını yazmışsa ona dokunulmuyor
json.dump({"api_key": "AIzaKENDI"}, open(yol, "w"))
a3 = lp.ayarlari_yukle()
kontrol("kullanıcının anahtarı eziliyor mu (ezilmemeli)", a3["api_key"] == "AIzaKENDI", a3["api_key"])

# çevirmen anahtarı görüyor mu
c = lp.Cevirmen(lp.ayarlari_yukle())
kontrol("çevirmen anahtarsız şikayet etmiyor", (c.ayarlar.get("api_key") or "").strip() != "")

sys.exit(1 if hata else 0)
