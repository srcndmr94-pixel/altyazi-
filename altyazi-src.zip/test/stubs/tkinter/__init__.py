class _W:
    def __init__(self,*a,**k): self._t=""
    def pack(self,*a,**k): pass
    def minsize(self,*a,**k): pass
    def config(self,**k): self._t=k.get("text",self._t)
    def cget(self,k): return self._t
    def update_idletasks(self): pass
    def winfo_width(self): return 100
    def winfo_screenwidth(self): return 1920
    def geometry(self,*a,**k): pass
    def deiconify(self): pass
    def withdraw(self): pass
    def lift(self): pass
    def overrideredirect(self,*a): pass
    def attributes(self,*a,**k): pass
    def configure(self,**k): pass
    def title(self,*a): pass
    def protocol(self,*a): pass
    def mainloop(self): pass
    def after(self,ms,fn=None,*a):
        if fn: fn()
    def destroy(self): pass
Tk=Toplevel=Label=_W
class StringVar:
    def __init__(self,value=""): self.v=value
    def get(self): return self.v
    def set(self,v): self.v=v
