"""Arayüz gerçekten kuruluyor mu, versiyon görünüyor mu?"""
import importlib.util, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "stubs"))
spec = importlib.util.spec_from_file_location("lingoplay", "/home/claude/project/pc/lingoplay_pc.py")
lp = importlib.util.module_from_spec(spec); spec.loader.exec_module(lp)

print("Sürüm:", lp.SURUM)
lp.main()   # stub mainloop hemen döner; hata olursa burada patlar
print("Arayüz hatasız kuruldu.")
