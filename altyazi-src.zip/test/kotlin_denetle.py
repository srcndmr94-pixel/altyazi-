"""
Kotlin'de "taşıma sırasında unutulan parametre" hatasını derlemeden önce yakalar.

Geniş bir denetim yanlış alarm üretiyor, o yüzden tek bir hata türüne
odaklanıyoruz: bir fonksiyon, BAŞKA bir fonksiyonun parametresi olan ama
kendisinde tanımlı olmayan bir ismi kullanıyorsa uyarıyoruz. Kodu bölüp
taşırken yapılan hata tam olarak budur ve derlemeyi durdurur.
"""

import os
import re
import sys

KOK = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "java")

FUN_BASI = re.compile(
    r"^[ \t]*(?:(?:private|public|internal|protected|override|suspend|inline|open)\s+)*"
    r"fun\s+(?:<[^>]+>\s*)?(\w+)\s*\(",
    re.M,
)


def temizle(kod):
    kod = re.sub(r"//[^\n]*", "", kod)
    kod = re.sub(r"/\*.*?\*/", "", kod, flags=re.S)
    kod = re.sub(r'"""(?:.|\n)*?"""', '""', kod)
    kod = re.sub(r'"(?:\\.|[^"\\\n])*"', '""', kod)
    return kod


def eslesen_kapanis(metin, acilis, ac, kapa):
    derinlik = 0
    for j in range(acilis, len(metin)):
        if metin[j] == ac:
            derinlik += 1
        elif metin[j] == kapa:
            derinlik -= 1
            if derinlik == 0:
                return j
    return len(metin) - 1


def fonksiyonlari_cikar(kod):
    """[(ad, parametre kümesi, gövde)] döndürür."""
    sonuc = []
    for m in FUN_BASI.finditer(kod):
        ad = m.group(1)
        acilis = kod.index("(", m.start())
        kapanis = eslesen_kapanis(kod, acilis, "(", ")")
        par = set(re.findall(r"(\w+)\s*:", kod[acilis + 1:kapanis]))

        govde_basi = kod.find("{", kapanis)
        esittir = kod.find("=", kapanis)
        if govde_basi == -1 or (esittir != -1 and esittir < govde_basi):
            # tek satırlık gövde: = ile başlar
            satir_sonu = kod.find("\n\n", kapanis)
            govde = kod[kapanis:satir_sonu if satir_sonu != -1 else len(kod)]
        else:
            son = eslesen_kapanis(kod, govde_basi, "{", "}")
            govde = kod[govde_basi + 1:son]
        sonuc.append((ad, par, govde))
    return sonuc


def yerel_isimler(govde):
    isimler = set()
    isimler |= set(re.findall(r"\b(?:val|var)\s+(\w+)", govde))
    isimler |= set(re.findall(r"\bcatch\s*\(\s*(\w+)\s*:", govde))
    isimler |= set(re.findall(r"\bfor\s*\(\s*(\w+)\s+in", govde))
    # for ((a, b) in ...) ve { a, b -> } gibi çoklu tanımlar
    for kalip in (r"\(\s*\((\w+)\s*,\s*(\w+)\)", r"\{\s*(\w+)\s*,\s*(\w+)\s*->"):
        for ikili in re.findall(kalip, govde):
            isimler |= set(ikili)
    isimler |= set(re.findall(r"\{\s*(\w+)\s*->", govde))
    # gövde içindeki iç içe fonksiyonların parametreleri de burada tanımlıdır
    for ic in re.finditer(r"\bfun\s+\w+\s*\(([^)]*)\)", govde):
        isimler |= set(re.findall(r"(\w+)\s*:", ic.group(1)))
    isimler |= set(re.findall(r"\bval\s*\((\w+)\s*,\s*(\w+)\)", govde) and
                   [x for t in re.findall(r"\bval\s*\((\w+)\s*,\s*(\w+)\)", govde) for x in t])
    return isimler


def denetle(yol):
    kod = temizle(open(yol, encoding="utf-8").read())
    sinif_uyeleri = set(re.findall(r"^\s*(?:private |)(?:@Volatile\s+)?(?:val|var|const val)\s+(\w+)",
                                   kod, re.M))
    fonksiyonlar = fonksiyonlari_cikar(kod)

    # Tüm parametre isimleri havuzu: bunlar "taşınabilir" isimlerdir.
    tum_parametreler = set()
    for _, par, _ in fonksiyonlar:
        tum_parametreler |= par

    sorunlar = []
    for ad, par, govde in fonksiyonlar:
        tanimli = par | yerel_isimler(govde) | sinif_uyeleri
        # yalnızca başka fonksiyonun parametresi olan isimleri kontrol et
        supheli = tum_parametreler - tanimli
        for isim in sorted(supheli):
            # nokta olmadan, tek başına kullanılıyor mu
            # adlandırılmış argüman (fonk(x = 1)) kullanım sayılmaz
            kullanim = re.search(rf"(?<![\w.]){re.escape(isim)}(?![\w])\s*(?!=[^=])", govde)
            adlandirilmis = re.search(rf"[(,]\s*{re.escape(isim)}\s*=[^=]", govde)
            if kullanim and not adlandirilmis:
                sorunlar.append((ad, isim))
    return sorunlar


def main():
    toplam = []
    for dizin, _, dosyalar in os.walk(KOK):
        for d in sorted(dosyalar):
            if d.endswith(".kt"):
                yol = os.path.join(dizin, d)
                for fonk, isim in denetle(yol):
                    toplam.append(f"{d} → fun {fonk}() içinde tanımsız olabilir: {isim}")

    if toplam:
        print("Olası tanımsız parametreler:")
        for satir in sorted(set(toplam)):
            print("  ✗", satir)
        return 1
    print("Kotlin parametre denetimi temiz.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
