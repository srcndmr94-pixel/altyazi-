"""401 alınca ikinci başlıkla tekrar deniyor mu?"""
import importlib.util, json, os, sys, threading
from http.server import BaseHTTPRequestHandler, HTTPServer
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "stubs"))

denemeler = []

class Sunucu(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def _basliklar(self):
        return {"x": self.headers.get("x-goog-api-key"),
                "auth": self.headers.get("Authorization")}
    def _yanit(self, kod, govde):
        veri = json.dumps(govde).encode()
        self.send_response(kod); self.send_header("content-type","application/json")
        self.send_header("content-length",str(len(veri))); self.end_headers(); self.wfile.write(veri)
    def do_POST(self):
        b = self._basliklar(); denemeler.append(b)
        if b["x"]:   # ilk deneme: 401 ver
            self._yanit(401, {"error":{"message":"Expected OAuth 2 access token"}})
        else:        # ikinci deneme: başarı
            self._yanit(200, {"candidates":[{"content":{"parts":[{"text":"Dışarıda bekliyor."}]}}]})
    def do_GET(self):
        b = self._basliklar(); denemeler.append(b)
        if b["x"]:
            self._yanit(401, {"error":{"message":"Expected OAuth 2 access token"}})
        else:
            self._yanit(200, {"models":[{"name":"models/gemini-3.1-flash-lite",
                                         "supportedGenerationMethods":["generateContent"]}]})

srv = HTTPServer(("127.0.0.1", 8742), Sunucu)
threading.Thread(target=srv.serve_forever, daemon=True).start()

kaynak = open("/home/claude/project/pc/lingoplay_pc.py",encoding="utf-8").read()
kaynak = kaynak.replace("https://generativelanguage.googleapis.com","http://127.0.0.1:8742")
y={}; exec(compile(kaynak,"t","exec"), y)

hata=[]
def k(ad,kosul,ek=""):
    print(("  ✓ " if kosul else "  ✗ ")+ad+("" if kosul else f"   {ek}")); 
    if not kosul: hata.append(ad)

print("A) Çeviri: 401 sonrası Bearer ile tekrar")
c = y["Cevirmen"](dict(y["VARSAYILAN"], api_key="AQ.TESTKEY1234567890"))
sonuc = c.cevir("He is waiting outside.")
k("iki deneme yapıldı", len(denemeler)==2, denemeler)
k("ilk deneme x-goog-api-key", denemeler[0]["x"]=="AQ.TESTKEY1234567890", denemeler[0])
k("ikinci deneme Bearer", denemeler[1]["auth"]=="Bearer AQ.TESTKEY1234567890", denemeler[1])
k("çeviri döndü", sonuc=="Dışarıda bekliyor.", sonuc)

denemeler.clear()
print("B) Model listesi: aynı davranış")
c2 = y["Cevirmen"](dict(y["VARSAYILAN"], api_key="AQ.TESTKEY1234567890"))
adlar = c2.modelleri_getir()
k("liste alındı", adlar==["gemini-3.1-flash-lite"], adlar)
k("iki deneme", len(denemeler)==2, denemeler)

srv.shutdown()
sys.exit(1 if hata else 0)
