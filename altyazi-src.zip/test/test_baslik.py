"""Program sunucuya hangi başlığı gönderiyor? Gerçek sunucu kurup bakıyoruz."""
import importlib.util, json, os, sys, threading
from http.server import BaseHTTPRequestHandler, HTTPServer
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "stubs"))

spec = importlib.util.spec_from_file_location("lingoplay", "/home/claude/project/pc/lingoplay_pc.py")
lp = importlib.util.module_from_spec(spec); spec.loader.exec_module(lp)

gelen = {}

class Sunucu(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _kaydet(self):
        gelen["authorization"] = self.headers.get("Authorization")
        gelen["x-goog-api-key"] = self.headers.get("x-goog-api-key")
        gelen["yol"] = self.path
    def do_POST(self):
        self._kaydet()
        cevap = {"candidates":[{"content":{"parts":[{"text":"Dışarıda bekliyor."}]},
                 "finishReason":"STOP"}], "usageMetadata":{"promptTokenCount":10,"candidatesTokenCount":5}}
        veri = json.dumps(cevap).encode()
        self.send_response(200); self.send_header("content-type","application/json")
        self.send_header("content-length",str(len(veri))); self.end_headers(); self.wfile.write(veri)
    def do_GET(self):
        self._kaydet()
        cevap = {"models":[{"name":"models/gemini-3.1-flash-lite",
                            "supportedGenerationMethods":["generateContent"]}]}
        veri = json.dumps(cevap).encode()
        self.send_response(200); self.send_header("content-type","application/json")
        self.send_header("content-length",str(len(veri))); self.end_headers(); self.wfile.write(veri)

srv = HTTPServer(("127.0.0.1", 8731), Sunucu)
threading.Thread(target=srv.serve_forever, daemon=True).start()

# istekleri yerel sunucuya yönlendir
kaynak = open("/home/claude/project/pc/lingoplay_pc.py", encoding="utf-8").read()
kaynak = kaynak.replace("https://generativelanguage.googleapis.com", "http://127.0.0.1:8731")
yerel = {}
exec(compile(kaynak, "lingoplay_test", "exec"), yerel)

hata = []
def kontrol(ad, kosul, ek=""):
    print(("  ✓ " if kosul else "  ✗ ") + ad + ("" if kosul else f"   {ek}"))
    if not kosul: hata.append(ad)

print("A) AQ. ile başlayan anahtar (sizin anahtarınızın türü)")
a = dict(yerel["VARSAYILAN"]); a["api_key"] = "AQ.Ab8RN6J9G3HMBqJ42-TEST"
c = yerel["Cevirmen"](a)
sonuc = c.cevir("He is waiting outside.")
kontrol("Authorization: Bearer gönderildi",
        gelen.get("authorization") == "Bearer AQ.Ab8RN6J9G3HMBqJ42-TEST", gelen)
kontrol("eski başlık gönderilmedi", gelen.get("x-goog-api-key") is None, gelen)
kontrol("çeviri geri döndü", sonuc == "Dışarıda bekliyor.", sonuc)

gelen.clear()
print("B) AIza ile başlayan eski anahtar")
a2 = dict(yerel["VARSAYILAN"]); a2["api_key"] = "AIzaSyTESTKEY1234567890"
c2 = yerel["Cevirmen"](a2)
c2.cevir("Hello there.")
kontrol("x-goog-api-key gönderildi", gelen.get("x-goog-api-key") == "AIzaSyTESTKEY1234567890", gelen)
kontrol("Bearer gönderilmedi", gelen.get("authorization") is None, gelen)

gelen.clear()
print("C) Model listesi de doğru başlıkla gidiyor mu")
c3 = yerel["Cevirmen"](dict(yerel["VARSAYILAN"], api_key="AQ.MODELTEST12345678"))
adlar = c3.modelleri_getir()
kontrol("model listesi alındı", adlar == ["gemini-3.1-flash-lite"], adlar)
kontrol("liste isteğinde de Bearer", gelen.get("authorization") == "Bearer AQ.MODELTEST12345678", gelen)

srv.shutdown()
sys.exit(1 if hata else 0)
