"""
LingoPlay PC — ekrandaki İngilizce altyazıyı anlık Türkçeye çevirir.

Windows için tek dosyalık program. Ekranın alt şeridini yakalar, yazıyı okur,
Google Gemini ile Türkçeye çevirir ve ekranın üstünde bir kutuda gösterir.

Android sürümüyle aynı mantık: kalıp sözlüğü önce, sonra kalıcı hafıza,
en son yapay zekâ. Bir replik için ekrana bir kez yazılır, değişmez.
"""

import json
import os
import re
import sys
import threading
import time
import tkinter as tk
import urllib.error
import urllib.request
from tkinter import ttk

try:
    import mss
except ImportError:
    mss = None

try:
    from rapidocr_onnxruntime import RapidOCR
except ImportError:
    RapidOCR = None


APP_DIR = os.path.join(os.path.expanduser("~"), ".lingoplay")
CONFIG_PATH = os.path.join(APP_DIR, "ayarlar.json")
MEMORY_PATH = os.path.join(APP_DIR, "hafiza.json")

VARSAYILAN = {
    "api_key": "",
    "model": "gemini-3.8",
    "oyun": "",
    "tur": "Oyun",
    "ust_yuzde": 74,
    "alt_yuzde": 99,
    "sol_yuzde": 8,
    "sag_yuzde": 92,
    "aralik_ms": 120,
    "konusan_goster": True,
    "ekran": 1,
}


# ---------------------------------------------------------------- kalıp sözlüğü

KALIPLAR = {
    "yes": "Evet", "no": "Hayır", "okay": "Tamam", "ok": "Tamam",
    "alright": "Pekâlâ", "all right": "Pekâlâ", "sure": "Tabii",
    "of course": "Elbette", "exactly": "Aynen öyle", "maybe": "Belki",
    "never": "Asla", "always": "Her zaman", "nothing": "Hiçbir şey",
    "i dont know": "Bilmiyorum", "i dont understand": "Anlamıyorum",
    "i see": "Anlıyorum", "got it": "Anladım", "understood": "Anlaşıldı",
    "forget it": "Boş ver", "never mind": "Boş ver", "no way": "Mümkün değil",
    "damn it": "Kahretsin", "what the hell": "Bu da ne böyle",
    "oh no": "Olamaz", "my god": "Tanrım",
    "hello": "Merhaba", "hi": "Selam", "hey": "Hey",
    "good morning": "Günaydın", "good evening": "İyi akşamlar",
    "good night": "İyi geceler", "goodbye": "Hoşça kal", "farewell": "Elveda",
    "see you": "Görüşürüz", "take care": "Kendine iyi bak",
    "thank you": "Teşekkür ederim", "thanks": "Teşekkürler",
    "youre welcome": "Rica ederim", "please": "Lütfen",
    "sorry": "Üzgünüm", "im sorry": "Üzgünüm", "excuse me": "Affedersiniz",
    "forgive me": "Beni bağışla", "congratulations": "Tebrikler",
    "well done": "Aferin", "good luck": "Bol şans",
    "look out": "Dikkat et", "watch out": "Dikkat et",
    "careful": "Dikkatli ol", "be careful": "Dikkatli ol",
    "get down": "Eğil", "take cover": "Siper al", "behind you": "Arkanda",
    "run": "Kaç", "move": "Kımılda", "go": "Git", "lets go": "Gidelim",
    "come on": "Hadi", "hurry": "Çabuk ol", "hurry up": "Acele et",
    "wait": "Bekle", "hold on": "Bir dakika", "stop": "Dur",
    "stop it": "Kes şunu", "stay back": "Geride dur", "stay here": "Burada kal",
    "follow me": "Beni takip et", "this way": "Bu taraftan",
    "over here": "Buraya", "get up": "Kalk", "im on it": "Hallediyorum",
    "leave it to me": "Bana bırak", "cover me": "Beni koru",
    "reloading": "Dolduruyorum", "theyre coming": "Geliyorlar",
    "hes dead": "Öldü", "dont move": "Kıpırdama", "dont": "Yapma",
    "its a trap": "Bu bir tuzak", "were surrounded": "Kuşatıldık",
    "i need help": "Yardıma ihtiyacım var", "help me": "Bana yardım et",
    "are you okay": "İyi misin", "are you all right": "İyi misin",
    "im fine": "İyiyim",
    "who are you": "Sen kimsin", "what is this": "Bu ne",
    "whats this": "Bu ne", "whats going on": "Neler oluyor",
    "what happened": "Ne oldu", "what do you mean": "Ne demek istiyorsun",
    "what do you want": "Ne istiyorsun", "where are you": "Neredesin",
    "where are we": "Neredeyiz", "why": "Neden", "why not": "Neden olmasın",
    "how": "Nasıl", "are you sure": "Emin misin",
    "do you understand": "Anlıyor musun", "can you hear me": "Beni duyuyor musun",
    "whos there": "Kim var orada", "what now": "Şimdi ne olacak",
    "i promise": "Söz veriyorum", "i swear": "Yemin ederim",
    "trust me": "Bana güven", "listen to me": "Beni dinle", "listen": "Dinle",
    "look at me": "Bana bak", "tell me": "Anlat bana",
    "its over": "Her şey bitti", "its too late": "Çok geç",
    "it doesnt matter": "Fark etmez", "theres no time": "Vakit yok",
    "i knew it": "Biliyordum", "youre right": "Haklısın",
    "youre wrong": "Yanılıyorsun", "im serious": "Ciddiyim",
    "are you serious": "Ciddi misin", "thats enough": "Bu kadar yeter",
    "enough": "Yeter", "calm down": "Sakin ol", "relax": "Rahatla",
    "dont worry": "Merak etme", "be quiet": "Sessiz ol",
    "shut up": "Kes sesini", "leave me alone": "Beni yalnız bırak",
    "get out": "Defol", "come with me": "Benimle gel",
    "stay with me": "Yanımda kal", "im coming": "Geliyorum",
    "im here": "Buradayım", "thank god": "Çok şükür",
    "i miss you": "Seni özledim", "i love you": "Seni seviyorum",
    "loading": "Yükleniyor", "saving": "Kaydediliyor",
    "checkpoint reached": "Kontrol noktasına ulaşıldı",
    "objective complete": "Görev tamamlandı", "new objective": "Yeni görev",
    "mission failed": "Görev başarısız", "level up": "Seviye atladın",
    "you died": "Öldün", "game over": "Oyun bitti", "continue": "Devam et",
    "skip": "Atla", "settings": "Ayarlar", "options": "Seçenekler",
    "inventory": "Envanter", "map": "Harita", "exit": "Çıkış",
}

ARAYUZ_KELIMELERI = {
    "l1", "l2", "l3", "r1", "r2", "r3", "ps", "touchpad", "skip",
    "options", "start", "select", "esc", "tab", "enter", "space",
}

KISALTMALAR = [
    ("dont", "don't"), ("doesnt", "doesn't"), ("didnt", "didn't"),
    ("cant", "can't"), ("couldnt", "couldn't"), ("wont", "won't"),
    ("wouldnt", "wouldn't"), ("shouldnt", "shouldn't"), ("isnt", "isn't"),
    ("arent", "aren't"), ("wasnt", "wasn't"), ("werent", "weren't"),
    ("havent", "haven't"), ("hasnt", "hasn't"), ("im", "I'm"),
    ("ive", "I've"), ("ill", "I'll"), ("youre", "you're"),
    ("youve", "you've"), ("hes", "he's"), ("shes", "she's"),
    ("thats", "that's"), ("theres", "there's"), ("theyre", "they're"),
    ("lets", "let's"), ("whats", "what's"),
]


def sadelestir(metin):
    return re.sub(r"[^a-z0-9 ]", "", metin.lower()).strip()


def metni_onar(ham):
    metin = ham.replace("…", "...")
    metin = re.sub(r"\s+", " ", metin).strip(" -—\"'")
    for yanlis, dogru in KISALTMALAR:
        metin = re.sub(rf"\b{yanlis}\b", dogru, metin, flags=re.IGNORECASE)
    return metin.strip()


def konusani_ayir(metin):
    """'JAMES: Merhaba' → ('JAMES', 'Merhaba'). İsim çeviriye girmez."""
    yer = metin.find(":")
    if 0 < yer <= 24:
        ad = metin[:yer].strip()
        geri = metin[yer + 1:].strip()
        if len(geri) > 1 and all(c.isalpha() or c in " .'-" for c in ad):
            return ad, geri
    return None, metin


# -------------------------------------------------------------------- hafıza

class Hafiza:
    """Çevrilen replikler diske yazılır; tekrar edince bedava ve anında gelir."""

    def __init__(self):
        self.veri = {}
        try:
            with open(MEMORY_PATH, encoding="utf-8") as f:
                self.veri = json.load(f)
        except Exception:
            self.veri = {}
        self.kilit = threading.Lock()

    def al(self, metin):
        return self.veri.get(sadelestir(metin))

    def koy(self, metin, ceviri):
        with self.kilit:
            self.veri[sadelestir(metin)] = ceviri
            if len(self.veri) > 5000:
                self.veri = dict(list(self.veri.items())[-3000:])
            try:
                os.makedirs(APP_DIR, exist_ok=True)
                with open(MEMORY_PATH, "w", encoding="utf-8") as f:
                    json.dump(self.veri, f, ensure_ascii=False)
            except Exception:
                pass


# ------------------------------------------------------------------- çeviri

class Cevirmen:
    def __init__(self, ayarlar):
        self.ayarlar = ayarlar
        self.gecmis = []
        self.son_hata = None
        self.son_sure = 0.0

    def talimat(self):
        tur = self.ayarlar.get("tur") or "Oyun"
        ad = self.ayarlar.get("oyun") or f"bilinmeyen bir {tur.lower()}"
        t = (
            f"{tur} altyazısı çevirmeni. {tur}: {ad}. "
            "OCR ile okunmuş İngilizce repliği doğal Türkçeye çevir. "
            "Özel isimleri çevirme. OCR hatalarını bağlamdan düzelt. "
            "Argoyu yumuşatma. Altyazı tek bakışta okunacak, kısa ve akıcı olsun. "
        )
        if self.ayarlar.get("konusan_goster"):
            t += "Replikte konuşan adı varsa 'İsim: çeviri' biçiminde koru. "
        t += "Sadece çeviriyi yaz, açıklama yazma, mutlaka bir çeviri ver."
        return t

    def modelleri_getir(self):
        """Hesabın kullanabildiği model adlarını getirir."""
        anahtar = (self.ayarlar.get("api_key") or "").strip()
        if not anahtar:
            self.son_hata = "API anahtarı girilmemiş"
            return []
        url = "https://generativelanguage.googleapis.com/v1beta/models"
        istek = urllib.request.Request(url)
        istek.add_header("x-goog-api-key", anahtar)
        try:
            with urllib.request.urlopen(istek, timeout=15) as cevap:
                veri = json.loads(cevap.read().decode("utf-8"))
        except Exception as e:
            self.son_hata = str(e)[:150]
            return []
        adlar = []
        for m in veri.get("models", []):
            if "generateContent" not in (m.get("supportedGenerationMethods") or []):
                continue
            ad = (m.get("name") or "").replace("models/", "")
            if ad:
                adlar.append(ad)
        return adlar

    @staticmethod
    def en_uygun(adlar):
        for ad in adlar:
            if "flash" in ad and "thinking" not in ad and "embedding" not in ad:
                return ad
        return adlar[0] if adlar else None

    def cevir(self, metin):
        self.son_sure = 0.0
        baslangic = time.time()
        sonuc = self._cevir(metin)
        self.son_sure = time.time() - baslangic
        return sonuc

    def _cevir(self, metin):
        anahtar = (self.ayarlar.get("api_key") or "").strip()
        if not anahtar:
            self.son_hata = "API anahtarı girilmemiş"
            return None

        icerik = []
        for en, tr in self.gecmis[-2:]:
            icerik.append({"role": "user", "parts": [{"text": en}]})
            icerik.append({"role": "model", "parts": [{"text": tr}]})
        icerik.append({"role": "user", "parts": [{"text": metin}]})

        govde = json.dumps({
            "system_instruction": {"parts": [{"text": self.talimat()}]},
            "contents": icerik,
            "generationConfig": {
                "maxOutputTokens": 256,
                # Düşünme kapalı: cevap sınırını tüketip boş yanıt dönmesini önler.
                "thinkingConfig": {"thinkingBudget": 0},
            },
        }).encode("utf-8")

        model = self.ayarlar.get("model") or "gemini-3.8"
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
        istek = urllib.request.Request(url, data=govde, method="POST")
        istek.add_header("content-type", "application/json")
        istek.add_header("x-goog-api-key", anahtar)

        try:
            with urllib.request.urlopen(istek, timeout=12) as cevap:
                veri = json.loads(cevap.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            try:
                detay = json.loads(e.read().decode("utf-8"))
                mesaj = detay.get("error", {}).get("message", "")
            except Exception:
                mesaj = ""
            self.son_hata = f"{e.code}: {mesaj[:120]}"
            return None
        except Exception as e:
            self.son_hata = str(e)[:120]
            return None

        try:
            parcalar = veri["candidates"][0]["content"]["parts"]
            sonuc = "".join(p.get("text", "") for p in parcalar).strip().strip('"')
        except Exception:
            sonuc = ""

        if not sonuc:
            self.son_hata = "boş yanıt"
            return None

        self.son_hata = None
        self.gecmis.append((metin, sonuc))
        self.gecmis = self.gecmis[-2:]
        return sonuc


# ------------------------------------------------------------------- ekran

class Kutu:
    """Ekranın üstünde duran, her zaman önde, tıklanamayan çeviri kutusu."""

    def __init__(self, kok):
        self.pencere = tk.Toplevel(kok)
        self.pencere.overrideredirect(True)
        self.pencere.attributes("-topmost", True)
        self.pencere.attributes("-alpha", 0.92)
        self.pencere.configure(bg="black")
        self.etiket = tk.Label(
            self.pencere, text="", font=("Segoe UI", 16, "bold"),
            fg="white", bg="black", wraplength=1100, justify="center",
            padx=16, pady=8,
        )
        self.etiket.pack()
        self.pencere.withdraw()

    def yaz(self, metin):
        if not metin:
            self.pencere.withdraw()
            return
        self.etiket.config(text=metin)
        self.pencere.update_idletasks()
        genislik = self.pencere.winfo_width()
        ekran = self.pencere.winfo_screenwidth()
        self.pencere.geometry(f"+{max(0, (ekran - genislik) // 2)}+40")
        self.pencere.deiconify()
        self.pencere.lift()


# -------------------------------------------------------------------- motor

class Motor(threading.Thread):
    def __init__(self, ayarlar, kutu, durum_yaz):
        super().__init__(daemon=True)
        self.ayarlar = ayarlar
        self.kutu = kutu
        self.durum_yaz = durum_yaz
        self.calisiyor = True
        self.hafiza = Hafiza()
        self.cevirmen = Cevirmen(ayarlar)
        self.ocr = RapidOCR() if RapidOCR else None
        self.gosterilen = ""
        self.bos_kare = 0
        self.isleniyor = set()
        self.kilit = threading.Lock()
        self.onceki_kare = None
        self.ocr_suresi = 0.0
        self.gosterim_zamani = 0.0

    def dur(self):
        self.calisiyor = False

    def bolge(self, sct):
        ekran_no = int(self.ayarlar.get("ekran", 1))
        ekranlar = sct.monitors
        ekran = ekranlar[ekran_no] if ekran_no < len(ekranlar) else ekranlar[0]
        yuk = ekran["height"]
        gen = ekran["width"]
        ust = ekran["top"] + int(yuk * self.ayarlar["ust_yuzde"] / 100)
        alt = ekran["top"] + int(yuk * self.ayarlar["alt_yuzde"] / 100)
        sol = ekran["left"] + int(gen * self.ayarlar["sol_yuzde"] / 100)
        sag = ekran["left"] + int(gen * self.ayarlar["sag_yuzde"] / 100)
        return {"top": ust, "left": sol, "width": max(8, sag - sol), "height": max(8, alt - ust)}

    def oku(self, goruntu):
        if not self.ocr:
            return ""
        try:
            sonuc, _ = self.ocr(goruntu)
        except Exception:
            return ""
        if not sonuc:
            return ""
        satirlar = []
        for kutu_, metin, guven in sonuc:
            t = (metin or "").strip()
            if not t or guven < 0.5:
                continue
            if sadelestir(t) in ARAYUZ_KELIMELERI:
                continue
            if len(t) < 3 or sum(c.isalpha() for c in t) < 3:
                continue
            ust = min(p[1] for p in kutu_)
            satirlar.append((ust, t))
        satirlar.sort()
        return " ".join(t for _, t in satirlar)

    def benzer(self, a, b):
        if not a or not b:
            return a == b
        na, nb = sadelestir(a), sadelestir(b)
        if na == nb:
            return True
        uzun, kisa = (na, nb) if len(na) >= len(nb) else (nb, na)
        if not uzun or len(kisa) / len(uzun) < 0.8:
            return False
        fark = sum(1 for x, y in zip(uzun, kisa) if x != y) + (len(uzun) - len(kisa))
        return fark / len(uzun) <= 0.12

    def run(self):
        if mss is None or self.ocr is None:
            self.durum_yaz("Gerekli bileşenler yüklenemedi.")
            return

        import numpy as np

        with mss.mss() as sct:
            while self.calisiyor:
                time.sleep(max(0.08, self.ayarlar["aralik_ms"] / 1000))
                try:
                    kare = sct.grab(self.bolge(sct))
                    dizi = np.array(kare)[:, :, :3]

                    # Görüntü küçültülürse OCR belirgin biçimde hızlanır.
                    if dizi.shape[1] > 960:
                        adim = int(dizi.shape[1] / 960) + 1
                        kucuk = dizi[::adim, ::adim]
                    else:
                        kucuk = dizi

                    # Kare neredeyse aynıysa OCR'a hiç girmiyoruz.
                    imza = kucuk[::4, ::4].astype(np.int16)
                    if self.onceki_kare is not None and imza.shape == self.onceki_kare.shape:
                        if np.abs(imza - self.onceki_kare).max() < 6:
                            continue
                    self.onceki_kare = imza

                    ocr_basla = time.time()
                    ham = self.oku(kucuk)
                    self.ocr_suresi = time.time() - ocr_basla
                except Exception as e:
                    self.durum_yaz(f"Okuma hatası: {type(e).__name__}: {e}")
                    self.onceki_kare = None
                    time.sleep(0.5)
                    continue

                # Ekranda 10 saniyedir aynı çeviri duruyorsa bir aksilik var;
                # takılı kalmasın diye temizliyoruz.
                if self.gosterilen and time.time() - self.gosterim_zamani > 10:
                    self.gosterilen = ""
                    self.kutu.yaz("")

                metin = metni_onar(ham)
                if len(metin) < 3:
                    self.bos_kare += 1
                    if self.bos_kare >= 6 and self.gosterilen:
                        self.gosterilen = ""
                        self.kutu.yaz("")
                    continue
                self.bos_kare = 0

                if self.benzer(metin, self.gosterilen):
                    continue

                # Beklemeden çeviriye gönder; aynı replik ikinci kez gitmez.
                with self.kilit:
                    if metin in self.isleniyor or len(self.isleniyor) >= 3:
                        continue
                    self.isleniyor.add(metin)

                threading.Thread(target=self.isle, args=(metin,), daemon=True).start()

    def isle(self, kaynak):
        try:
            self._isle(kaynak)
        finally:
            with self.kilit:
                self.isleniyor.discard(kaynak)

    def _isle(self, kaynak):
        ad, govde = konusani_ayir(kaynak)

        kalip = KALIPLAR.get(sadelestir(govde))
        if kalip:
            self.goster(kaynak, f"{ad}: {kalip}" if ad else kalip)
            return

        kayitli = self.hafiza.al(kaynak)
        if kayitli:
            self.goster(kaynak, kayitli)
            return

        ceviri = self.cevirmen.cevir(kaynak)
        if ceviri:
            self.hafiza.koy(kaynak, ceviri)
            self.goster(kaynak, ceviri)
            self.durum_yaz(
                f"OCR {int(self.ocr_suresi * 1000)} ms · "
                f"çeviri {int(self.cevirmen.son_sure * 1000)} ms"
            )
        else:
            self.durum_yaz(f"Çeviri alınamadı: {self.cevirmen.son_hata}")

    def goster(self, kaynak, metin):
        self.gosterilen = kaynak
        self.gosterim_zamani = time.time()
        self.kutu.yaz(metin)


# ------------------------------------------------------------------ arayüz

def ayarlari_yukle():
    ayarlar = dict(VARSAYILAN)
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            ayarlar.update(json.load(f))
    except Exception:
        pass
    return ayarlar


def ayarlari_kaydet(ayarlar):
    try:
        os.makedirs(APP_DIR, exist_ok=True)
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(ayarlar, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def main():
    ayarlar = ayarlari_yukle()

    kok = tk.Tk()
    kok.title("LingoPlay")
    kok.geometry("520x520")

    cerceve = ttk.Frame(kok, padding=16)
    cerceve.pack(fill="both", expand=True)

    ttk.Label(cerceve, text="LingoPlay", font=("Segoe UI", 18, "bold")).pack(anchor="w")
    ttk.Label(
        cerceve,
        text="Ekrandaki İngilizce altyazıyı anlık Türkçeye çevirir.",
    ).pack(anchor="w", pady=(0, 12))

    alanlar = {}

    def alan(etiket, anahtar, gizli=False):
        ttk.Label(cerceve, text=etiket).pack(anchor="w", pady=(8, 0))
        degisken = tk.StringVar(value=str(ayarlar.get(anahtar, "")))
        giris = ttk.Entry(cerceve, textvariable=degisken, show="*" if gizli else "")
        giris.pack(fill="x")
        alanlar[anahtar] = degisken

    alan("Google AI Studio anahtarı (AIza... ile başlar)", "api_key")

    ttk.Label(cerceve, text="İçerik türü").pack(anchor="w", pady=(8, 0))
    tur_degisken = tk.StringVar(value=ayarlar.get("tur", "Oyun"))
    ttk.Combobox(
        cerceve, textvariable=tur_degisken, state="readonly",
        values=["Oyun", "Dizi", "Film", "Belgesel", "Video"],
    ).pack(fill="x")
    alanlar["tur"] = tur_degisken

    alan("Oyun / dizi / film adı (çeviri bağlamı için)", "oyun")

    ttk.Label(cerceve, text="Model").pack(anchor="w", pady=(8, 0))
    model_degisken = tk.StringVar(value=str(ayarlar.get("model", "")))
    model_kutusu = ttk.Combobox(cerceve, textvariable=model_degisken)
    model_kutusu.pack(fill="x")
    alanlar["model"] = model_degisken
    alan("Altyazı bölgesi üst yüzde", "ust_yuzde")
    alan("Altyazı bölgesi alt yüzde", "alt_yuzde")
    alan("Ekran numarası (1 = ana ekran)", "ekran")
    alan("Tarama aralığı ms (küçük = daha hızlı)", "aralik_ms")

    durum = tk.StringVar(value="Hazır.")
    ttk.Label(cerceve, textvariable=durum, wraplength=470).pack(anchor="w", pady=(14, 0))

    kutu = Kutu(kok)
    motor = {"nesne": None}

    def durum_yaz(metin):
        kok.after(0, lambda: durum.set(metin))

    def kaydet():
        for anahtar, degisken in alanlar.items():
            deger = degisken.get().strip()
            if anahtar in ("ust_yuzde", "alt_yuzde", "ekran", "aralik_ms"):
                try:
                    ayarlar[anahtar] = int(deger)
                except ValueError:
                    pass
            else:
                ayarlar[anahtar] = deger
        ayarlari_kaydet(ayarlar)

    def baslat_durdur():
        if motor["nesne"]:
            motor["nesne"].dur()
            motor["nesne"] = None
            kutu.yaz("")
            dugme.config(text="BAŞLAT")
            durum.set("Durduruldu.")
            return
        kaydet()
        m = Motor(ayarlar, kutu, durum_yaz)
        m.start()
        motor["nesne"] = m
        dugme.config(text="DURDUR")
        durum.set("Çalışıyor. Oyunu açabilirsiniz.")

    def test_et():
        kaydet()
        durum.set("Deneniyor...")

        def calis():
            c = Cevirmen(ayarlar)
            sonuc = c.cevir("He is waiting outside.")
            if sonuc:
                durum_yaz(f"Çeviri çalışıyor: {sonuc}")
            else:
                durum_yaz(f"Çeviri başarısız: {c.son_hata}")

        threading.Thread(target=calis, daemon=True).start()

    def modelleri_bul():
        kaydet()
        durum.set("Modeller aranıyor...")

        def calis():
            c = Cevirmen(ayarlar)
            adlar = c.modelleri_getir()
            if not adlar:
                durum_yaz(f"Model listesi alınamadı: {c.son_hata}")
                return
            secilen = Cevirmen.en_uygun(adlar)

            def arayuze_yaz():
                model_kutusu["values"] = adlar
                if secilen:
                    model_degisken.set(secilen)
                    ayarlar["model"] = secilen
                    ayarlari_kaydet(ayarlar)
                durum.set(
                    f"{len(adlar)} model bulundu. Seçilen: {secilen}. "
                    "Listeden başkasını da seçebilirsiniz."
                )

            kok.after(0, arayuze_yaz)

        threading.Thread(target=calis, daemon=True).start()

    dugme = ttk.Button(cerceve, text="BAŞLAT", command=baslat_durdur)
    dugme.pack(fill="x", pady=(16, 4))
    ttk.Button(cerceve, text="MODELLERİ BUL", command=modelleri_bul).pack(fill="x", pady=(0, 4))
    ttk.Button(cerceve, text="ÇEVİRİYİ TEST ET", command=test_et).pack(fill="x")

    kok.protocol("WM_DELETE_WINDOW", lambda: (kaydet(), kok.destroy()))
    kok.mainloop()


if __name__ == "__main__":
    try:
        main()
    except Exception as hata:
        print("Beklenmeyen hata:", hata)
        input("Kapatmak için Enter'a basın...")
